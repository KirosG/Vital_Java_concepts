1. Write a program that uses while loop and print out the following sequence
 
 Seq2- 5, 45, 405, 3645
 

2. Write a program that uses for loop and prints out the following sequence

 Seq1- 1 , 6, 36, 216, 1296, 7776
