package perScholasPackage;

class DisplayMessage {
	void printMessage() {
		System.out.println("Hello My Message");
	}
}
