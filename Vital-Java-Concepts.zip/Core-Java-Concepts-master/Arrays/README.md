Given two sorted Arrays of the size N, create a program 
 that creates a third sorted Array of size N and populates the third array 
 whenever there is a value that exist in both of the giving Arrays, at the same index. 
