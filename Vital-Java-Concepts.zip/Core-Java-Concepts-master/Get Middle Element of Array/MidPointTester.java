package perScholasPackage;

public class MidPointTester {
	public static void main(String[] args) {
		MidPointChecker test = new MidPointChecker(15);
		System.out.println(test.toString());
	}
}
