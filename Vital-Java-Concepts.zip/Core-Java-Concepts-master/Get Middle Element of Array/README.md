 Write a program to read an integer array and return the middle element in the array. 
Assume that the array will always be of odd length; also assume that the maximum number 
of elements in the array is 25 

Implement this program using two classes:
 Main class
 UserMainClass- 
 
 This class should have a method getMiddle() which should accept  
 one integer array as  parameter and return type should be integer
