Write a program to implement String to Date conversion.
