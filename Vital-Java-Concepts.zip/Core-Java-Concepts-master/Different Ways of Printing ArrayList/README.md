Different ways of printing the contents of an ArrayList.
