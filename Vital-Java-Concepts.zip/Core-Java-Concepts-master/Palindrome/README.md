Write a program that accepts two integers and returns all the available 
palindromes within that input number range. 

(The first input number would 
be the lower limit and the second input number would be the upper limit)
